let name;
let life;
let money;
let awake = true;
const tempsAléa = 7000;

function initMonstre(nom, vie, argent){
    name = nom;
    life = vie;
    money = argent;
}

function afficheMonstre(){
    console.log("Nom : " + name + ", Nombre de PV : " + life + ", Argent : " + money + ", Réveiller : " + awake);
    logBoite("Nom : " + name + ", Nombre de PV : " + life + ", Argent : " + money + ", Réveiller : " + awake);
}

let run = document.getElementById("run");
let fight = document.getElementById("fight");
let work = document.getElementById("work");
let sleep = document.getElementById("sleep");
let eat = document.getElementById("eat");
let show = document.getElementById("show");
setInterval(actionauhasard, tempsAléa);
let nouveau = document.getElementById("new");
let kill = document.getElementById("kill");
let monster = document.getElementById("monster");


function go() {
    initMonstre("Herobrine", 20, 20);
    boxMonstre();
    bordureMonstre();
    updateStatus();
    show.addEventListener("click", function() {
        afficheMonstre(); 
    });
}

window.addEventListener("load", go);

function logBoite(message){
    let actionbox = document.getElementById("actionbox");
    let texte = document.createElement("p");
    texte.textContent = message;
    actionbox.insertBefore(texte, actionbox.firstChild);
}

function updateStatus(){
    let statut = document.getElementById("statut");
    let liste = statut.querySelectorAll("li");

    for (let i = 0; i < liste.length; i++){
        statut.removeChild(liste[i]);
    }

    let pv = document.createElement("li");
    pv.textContent = "Nombre de PV : " + life + "PV";
    statut.appendChild(pv);

    let argent = document.createElement("li");
    argent.textContent = "Argent : " + money + "€";
    statut.appendChild(argent);

    let reveil = document.createElement("li");
    if(awake && life > 0){
        reveil.textContent = name + " est réveillé";
    } else if(!awake && life > 0){
        reveil.textContent = name + " s'est endormi";
    }
    else{
        reveil.textContent = name + " est mort"
        awake = "Mort";
    }
    statut.appendChild(reveil);
}

function courir(){
    if(awake){
        if(life > 1){
            life = life - 1;
            logBoite(name + " est en train de courir. (-1 PV)");
            boxMonstre();
            bordureMonstre();
            updateStatus();
        } else {
            logBoite(name + "  va mourir s'il continue à courir : STOP !");
        }
    } else {
        logBoite(name + "  court dans ses rêves !");
    }
}
run.addEventListener("click", courir);

function sebattre(){
    if(awake){
        if(life > 3){
            life = life - 3;
            logBoite(name + "  se bagarre. (-3 PV)");
            boxMonstre();
            bordureMonstre();
            updateStatus();
        } else {
            logBoite(name + "  va mourir s'il continue à se battre : STOP !");
        }
    } else {
        logBoite(name + "  se bat dans ses rêves.");
    }
}
fight.addEventListener("click", sebattre);

function travailler(){
    if(awake){
        if(life > 1){
            life = life - 1;
            money = money + 2;
            logBoite(name + "  bosse. (-1 PV, + 2€)");
            boxMonstre();
            bordureMonstre();
            updateStatus();
        } else {
            logBoite(name + "  va mourir s'il continue à bosser : STOP !");
        }
    } else {
        logBoite(name + "  dort, il ne peut pas bosser.");
    }
}
work.addEventListener("click", travailler);

function manger(){
    if(awake){
        if(money > 2){
            life = life + 2;
            money = money - 3;
            logBoite(name + "  est en train de bouffer. (+2 PV, - 3€)");
            boxMonstre();
            bordureMonstre();
            updateStatus();
        } else {
            logBoite(name + "  n'a pas assez d'argent pour s'acheter à manger : STOP !");
        }
    } else {
        logBoite(name + "  est en train de dormir, il ne peut pas manger.");
    }
}
eat.addEventListener("click", manger);

function dormir(){
    if(awake && life > 0){
        run.disabled = true;
        fight.disabled = true;
        work.disabled = true;
        eat.disabled = true;
        awake = false;
        logBoite(name + "  s'endort paisiblement.");
        boxMonstre();
        bordureMonstre();
        updateStatus();
        setTimeout(function(){
            if(life > 0){
                awake = true;
                run.disabled = false;
                fight.disabled = false;
                work.disabled = false;
                eat.disabled = false;
                life = life +1;
                logBoite(name + "  s'est bien reposé. (+1 PV)");
                boxMonstre();
                bordureMonstre();
                updateStatus();
            }
        }, 5000)
    } else if(life < 1){
        nouveau.disabled = false;
        logBoite(name + "  est décédé, il dormira à tout jamais... ");
    }
    else if(awake === false){
        logBoite(name + "  s'est déjà endormi.")
    }
}
sleep.addEventListener("click", dormir);

function actionauhasard() {
    
    let randomindex = Math.floor(Math.random() * tableauaction.length);
    let randomaction = tableauaction[randomindex];
    if(randomaction === 0){
        courir();
    }
    if(randomaction === 1){
        sebattre();
    }
    if(randomaction === 2){
        travailler();
    }
    if(randomaction === 3){
        manger();
    }
    if(randomaction === 4){
        dormir();
    }
    if(life > 0){
        randomaction();
    }
}

function Kill(){
    if(life > 0){
        life = 0;
        money = 0;
        nouveau.disabled = false;
        kill.disabled = true;
        eat.disabled = true;
        sleep.disabled = true;
        work.disabled = true;
        fight.disabled = true;
        run.disabled = true;
        boxMonstre();
        bordureMonstre();
        updateStatus();
    }
}
kill.addEventListener("click", Kill);

function NewLife(){
    if(life < 1){
        awake = true;
        run.disabled = false;
        fight.disabled = false;
        work.disabled = false;
        sleep.disabled = false;
        eat.disabled = false;
        kill.disabled = false;
        nouveau.disabled = true;
        initMonstre("Herobrine", 20, 20);
        boxMonstre();
        bordureMonstre();
        updateStatus();
    }
}
nouveau.addEventListener("click", NewLife);

nouveau.disabled = true;

function boxMonstre(){

    let monstreContainer = document.getElementById("monstre-container");
    monstreContainer.style.display = "block";
}

function bordureMonstre(){
    let monstreImage = document.getElementById("monstre-image");
    monstreImage.style.border = "2px solid black";
}

let eatTofu = document.getElementById("eatTofu");
eatTofu.addEventListener("click", mangerTofu);


function mangerTofu() {
    if (awake) {
        if (money > 2) {
            life += 5;
            money -= 2;
            logBoite(name + "  mange du tofu. (+5 PV, -2€)");
            boxMonstre();
            bordureMonstre();
            updateStatus();
        } else {
            logBoite(name + "  n'a pas assez d'argent pour acheter du tofu : STOP !");
        }
    } else {
        logBoite(name + "  est en train de dormir, il ne peut pas manger du tofu.");
    }
}

let submitName = document.getElementById("submitName");
submitName.addEventListener("click", function() {
    let monsterNameInput = document.getElementById("monsterName");
    let monsterName = monsterNameInput.value;
    initMonstre(monsterName, 20, 20);
});


function prendreRER() {
    if (awake) {
      if (life > 0) {
        const random = Math.random();
  
        if (random < 0.8) {
          life -= 3;
          logBoite(name + "  prend le RER. (-3 PV)");
        } else {
          life -= 10;
          logBoite(name + "  prend le RER mais il est en panne. (-10 PV)");
        }
  
        boxMonstre();
        bordureMonstre();
        updateStatus();
      } else {
        logBoite(name + "  ne peut pas prendre le RER, il est mort !");
      }
    } else {
      logBoite(name + "  dort, il ne peut pas prendre le RER.");
    }
  }
  
  
let rer = document.getElementById("rer");
rer.addEventListener("click", prendreRER);

function jouerRouletteRusse() {
    if (awake) {
      if (life > 0) {
        const random = Math.random();
  
        if (random < 1 / 6) {
          life = 0;
          logBoite("BOOM ! Le monstre est mort !");
        } else {
          logBoite("Clic ! Rien ne se passe.");
        }
  
        boxMonstre();
        bordureMonstre();
        updateStatus();
      } else {
        logBoite(name + "  est déjà mort, il ne peut pas jouer à la roulette russe !");
      }
    } else {
      logBoite(name + "  dort, il ne peut pas jouer à la roulette russe.");
    }
  }
  
  let rouletteRusse = document.getElementById("roulette-russe");
  rouletteRusse.addEventListener("click", jouerRouletteRusse);
  

  function allerEcole() {
    if (awake) {
      if (life > 0) {
        awake = false;
        logBoite(name + "  va à l'école...");
  
        setTimeout(function () {
          life--;
          awake = true;
          logBoite(name + "  est revenu de l'école. Il perd 1 point de vie.");
  
          boxMonstre();
          bordureMonstre();
          updateStatus();
        }, 10000);
      } else {
        logBoite(name + "  est déjà mort, il ne peut pas aller à l'école !");
      }
    } else {
      logBoite(name + "  dort, il ne peut pas aller à l'école'.");
    }
  }
  
  let ecole = document.getElementById("aller-ecole");
  ecole.addEventListener("click", allerEcole);
  
    var countdownDuration = 120;
    var countdownInterval;

function updateCountdown() {
  var countdownElement = document.getElementById('countdown');

  countdownElement.textContent = countdownDuration;

  countdownDuration--;

  if (countdownDuration < 0) {
    clearInterval(countdownInterval);
    dormir();
    countdownDuration = 120;
    countdownInterval = setInterval(updateCountdown, 1000);
  }
}

updateCountdown();

countdownInterval = setInterval(updateCountdown, 1000);

