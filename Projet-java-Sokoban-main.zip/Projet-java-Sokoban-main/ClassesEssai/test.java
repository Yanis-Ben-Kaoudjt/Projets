

public class test{

    public static void main(String argv[]) {
        Application app = new Application(argv);
        app.run();
    }
}