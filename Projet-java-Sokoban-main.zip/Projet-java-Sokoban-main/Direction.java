public enum Direction{

    HAUT,
    BAS,
    GAUCHE,
    DROITE,
    NODIRECTION,

    
}